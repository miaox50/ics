export const MEMBER_API = process.env.API_URL || 'http://127.0.0.1:5000/test/json';
export const MEMBERS_ENDPOINT = "http://localhost:5000/test/member"