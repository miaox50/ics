"use client";

import React, { useEffect, useState } from "react";
import { MEMBERS_ENDPOINT } from "../utils/constants";
import { Pagination } from "./Pagination";
import { Sorting } from "./Sorting";
import {MembersView} from "./MembersView";

export interface MemberInfo {
  namelist: string;
  lastname: string;
  firstname: string;
  middlename: string;
  courtesy: string;
  bioguideID: string;
  "office-room": string;
  "office-building": string;
}

export interface Member {
  statedistrict: string;
  "member-info": MemberInfo;
}

export const Members: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [members, setMembers] = useState<Member[]>([]);
  const [url, setUrl] = useState<string>(MEMBERS_ENDPOINT);
  const [hasnextFromSrv, setHasnextFromSrv] = useState(false);
  const [pageParams, setPageParams] = useState("");
  const [sortParams, setSortParams] = useState("");

  const buildUrlWithParams = (page: string, sort: string): string => {
    let ret = "";
    if (page === "" && sort === "") {
      ret = MEMBERS_ENDPOINT;
    } else if (page === "") {
      if (sort === "default") {
        ret = MEMBERS_ENDPOINT;
      } else {
        ret = MEMBERS_ENDPOINT + "?" + sort;
      }
    } else if (sort === "") {
      ret = MEMBERS_ENDPOINT + "?" + page;
    } else {
      if (sort === "default") {
        ret = MEMBERS_ENDPOINT + "?" + page;
      } else {
        ret = MEMBERS_ENDPOINT + "?" + page + "&" + sort;
      }
    }
    return ret;
  };
  const onPageParamsChange = (newPageParams: string) => {
    setPageParams(newPageParams);
    setUrl(buildUrlWithParams(newPageParams, sortParams));
  };

  const onSortingParamsChange = (newSortParams: string) => {
    setSortParams(newSortParams);
    setUrl(buildUrlWithParams(pageParams, newSortParams));
  };

  useEffect(() => {
    let ctrl: AbortController | null = new AbortController();

    fetch(url, { signal: ctrl.signal })
      .then((res) => {
        const pageInfo = JSON.parse(res.headers?.get("X-Pagination") ?? "");
        if (pageInfo?.hasnext === false || pageInfo?.hasnext === true) {
          setHasnextFromSrv(pageInfo?.hasnext);
        }

        return res.json();
      })
      .then((data) => {
        setMembers(data);
        setIsLoading(false);
        ctrl = null;
      })
      .catch((err) => {
        if (err.name === "AbortError") {
          console.log("aborted action");
        } else {
          console.log(err);
          setIsLoading(false);
        }
      });

    return () => {
      // clean up function
      ctrl?.abort();
    };
  }, [url]);

  if (isLoading) {
    return <h1>loading...</h1>;
  }
  return (
    <>
      <Sorting onSortingParamsChange={onSortingParamsChange} />
      <MembersView members={members} />
      <Pagination
        hasNext={hasnextFromSrv}
        onPageParamsChange={onPageParamsChange}
      />
    </>
  );
};
