"use client";

import React, { useState } from "react";

import "@/styles/Pagination.css";

export interface IPageProps {
  hasNext: boolean;
  onPageParamsChange: (pageParams: string) => void;
}

export const Pagination: React.FC<IPageProps> = (props: IPageProps) => {
  const [pageSize, setPageSize] = useState(10);
  const [pageNumber, setPageNumber] = useState(1);

  const buildParamsString = (pgSize: number, pageNum: number): string => {
    return "pageSize=" + pgSize + "&pageNumber=" + pageNum;
  };

  const handleNext = () => {
    const next = pageNumber + 1;
    setPageNumber(next);
    props.onPageParamsChange(buildParamsString(pageSize, next));
  };
  const handlePrev = () => {
    const prev = pageNumber - 1;
    if (prev <= 0) {
      return;
    }
    setPageNumber(prev);
    props.onPageParamsChange(buildParamsString(pageSize, prev));
  };

  const handlePageSize = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const pgSize = parseInt(e.target.value);
    setPageSize(pgSize);
    setPageNumber(1); //reset page number to stay in range
    props.onPageParamsChange(buildParamsString(pgSize, 1));
  };

  return (
    <span className="pagination">
      <label className="control-margin-right">
        Page size:
        <select name="pageSize" value={pageSize} onChange={handlePageSize}>
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="30">30</option>
          <option value="40">40</option>
        </select>
      </label>

      <button
        name="prev"
        className="control-margin-right"
        onClick={handlePrev}
        disabled={pageNumber == 1}
      >
        Prev
      </button>

      <label className="control-margin-right">Page number: {pageNumber} </label>
      <button name="next" onClick={handleNext} disabled={!props.hasNext}>
        Next
      </button>
    </span>
  );
};
