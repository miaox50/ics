"use client";

import React, { useState } from "react";
import { Member } from "./Members";

import "@/styles/MembersView.css";

export interface IMembersViewProps {
  members: Member[];
}

export const MembersView: React.FC<IMembersViewProps> = (
  props: IMembersViewProps
) => {
  if(props.members?.length === 0){
    return (<h1>no results found.</h1>)
  }
  return (
    <>
      <ul className="member-list">
        {props.members?.map((member: any) => {
          const memberinfo = member["member-info"];
          if (!memberinfo) {
            return <></>;
          }
          return (
            <li key={member.statedistrict}>
              <div className="memberName">{memberinfo.namelist}</div>
              <div className="chip">{memberinfo.bioguideID}</div>
              <div className="chip">{memberinfo.courtesy}</div>
              <div className="chip">{memberinfo["office-room"]}</div>
              <div className="chip">{memberinfo["office-building"]}</div>
              <div className="chip">{member.statedistrict}</div>
            </li>
          );
        })}
      </ul>
    </>
  );
};
