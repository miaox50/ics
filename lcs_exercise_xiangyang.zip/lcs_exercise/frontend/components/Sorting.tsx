"use client";

import React, { useState } from "react";

export interface ISortingProps {
  onSortingParamsChange: (sortingParams: string) => void;
}

export const Sorting: React.FC<ISortingProps> = (props: ISortingProps) => {
  const [sortingBy, setSortingBy] = useState("default");

  const buildParamsString = (sortingOption: string): string => {
    if (sortingOption === "default") {
      return "";
    }
    return "orderBy=" + sortingOption;
  };

  const handleSelection = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const sortingOption = e.target.value;
    setSortingBy(sortingOption);

    props.onSortingParamsChange(buildParamsString(sortingOption));
  };

  return (
    <>
      <label>
        Sort by:
        <select name="sorting" value={sortingBy} onChange={handleSelection}>
          <option value="default">default (not sorted)</option>
          <option value="firstname">firstname</option>
          <option value="lastname">lastname</option>
        </select>
      </label>
      <p>
        Only first name and last name sorting is supported. The default is not
        sorted. Sorting is applied first, then pagination is applied on top of
        it.
      </p>
    </>
  );
};
