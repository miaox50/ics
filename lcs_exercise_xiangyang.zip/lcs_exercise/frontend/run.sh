#!/usr/bin/env sh
yarn install && yarn dev