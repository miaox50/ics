# LCS Programming Exercise
For this exercise, I focused on the first three requirements: listing, sorting, and
pagination. I am very pleased with the results of this exercise and I believe that my solution meets these requirements. I would like to thank you for the opportunity to do it.


## Running the application
The application architecture is kept the same. And no changes are made to the run command.

```
$ cd api
$ dotnet watch run
```
and
```
$ cd frontend
$ yarn install
$ yarn dev
```

## Overview
For this exercise, I evenly distributed the effort on the backend and frontend. The backend implemented the listing, sorting, and pagination tasks. The frontend focused on representing the data and interacting with users.


## Code changes

### Back end:

- A new function was added to the service to convert a JSON document to a collection of objects. 
- Model classes were added for the JSON serializer to convert to objects. 
- A queryParams modal class was added to define query parameters. 
- The get method in the controller was implemented. It does the following:

    - Validates query parameters.
    - Updates the response header to include pagination metadata.
    - Returns sorted and pagination-ready data back to the front end.

Note: Updated the builder.service to allow customized header property.

### Front end:
The front-end changes include the creation of four React components: Members, MembersView, Pagination, and Sorting.

- The Members component is the main component that loads the backend data and delegates tasks to subcomponents. 
- The MembersView component is responsible for rendering a list of members, including a namelist at the top and several chips representing the attributes. 
- The Pagination component displays the paging information and allows users to navigate through the results. 
- The Sorting component allows users to sort the results by first name or last name.

In addition to the four React components, a few CSS files were added to make the app more appealing.

## Testing

Due to time constraints, unit testing was left out of the project. However, manual testing was conducted for the app. For example, the backend was tested by the following URLs:

```
http://localhost:5000/test/member?orderBy=firstname OK
http://localhost:5000/test/member?orderBy=lastname OK
http://localhost:5000/test/member?orderBy=middlename bad request
http://localhost:5000/test/member?orderBy=  bad request
http://localhost:5000/test/member?order OK (ignored unused query param)
http://localhost:5000/test/member?orderBy=firstname&PageNumber=3  OK
http://localhost:5000/test/member?orderBy=firstname&PageNumber=300 bad request(page number is too big)
http://localhost:5000/test/member?orderBy=firstname&PageNumber=3&pagesize=20 (OK)
http://localhost:5000/test/member?orderBy=firstname&PageNumber=3&pagesize=50 bad request(pagesize > 40)
http://localhost:5000/test/member?others=ignored   OK (return default query result)
 ```