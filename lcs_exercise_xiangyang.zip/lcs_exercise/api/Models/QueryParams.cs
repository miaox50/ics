using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace exercise.Models
{
    public class QueryParams
    {
        const int maxPageSize = 40;
        private int _pageSize = 10;
        public int PageNumber { get; set; } = 1;

        [Range(5, 40, ErrorMessage = "Page size must be between 5 and 40")]
        public int PageSize
        {
            get { return _pageSize; }
            set { _pageSize = value; }
        }

        public string OrderBy {get; set;} = "";
    }
}