using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace exercise.Models
{
    public class MemberInfo
    {
        [JsonPropertyName("namelist")]
        public string? Namelist { get; set; }
        [JsonPropertyName("lastname")]
        public string? Lastname { get; set; }
        [JsonPropertyName("firstname")]
        public string? Firstname { get; set; }
        [JsonPropertyName("middlename")]
        public string? Middlename { get; set; }
        [JsonPropertyName("bioguideID")]
        public string? BioguideID { get; set; }
        [JsonPropertyName("office-building")]
        public string? OfficeBuilding { get; set; }
        [JsonPropertyName("office-room")]
        public string? OfficeRoom { get; set; }
        [JsonPropertyName("office-zip")]
        public string? OfficeZip { get; set; }
        [JsonPropertyName("official-name")]
        public string? OfficialName { get; set; }
        [JsonPropertyName("courtesy")]
        public string? Curtesy { get; set; }


    }
}