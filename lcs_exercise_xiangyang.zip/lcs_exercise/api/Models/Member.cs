using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace exercise.Models
{
    public class Member
    {
        [JsonPropertyName("statedistrict")]
        public string? Statedistrict { get; set; }

        [JsonPropertyName("member-info")]
        public MemberInfo? MemberInfoV { get; set; }
    }
}