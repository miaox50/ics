using System.Text.Json;
using exercise.Services;
using Microsoft.AspNetCore.Mvc;
using exercise.Models;
using Newtonsoft.Json;

namespace exercise.Controllers;

[ApiController]
[Route("[controller]")]
[Produces("application/json")]
public class TestController : ControllerBase
{
    private MemberDataService service;

    public TestController(MemberDataService service)
    {
        this.service = service;
    }

    // Simple GET controller to check that things are wired up properly.
    // `curl http://localhost:5124/test` should return `"ok"`.

    /**
    Testing: 
    http://localhost:5000/test/member?orderBy=firstname OK
    http://localhost:5000/test/member?orderBy=lastname OK
    http://localhost:5000/test/member?orderBy=middlename bad request
    http://localhost:5000/test/member?orderBy=  bad request
    http://localhost:5000/test/member?order     OK (ignored unused query param)
    http://localhost:5000/test/member?orderBy=firstname&PageNumber=3  OK
    http://localhost:5000/test/member?orderBy=firstname&PageNumber=300 bad request(page number is too big)
    http://localhost:5000/test/member?orderBy=firstname&PageNumber=3&pagesize=20 (OK)
    http://localhost:5000/test/member?orderBy=firstname&PageNumber=3&pagesize=50 bad request(pagesize > 40)
    http://localhost:5000/test/member?others=ignored   OK (return default query result)
    */
    [HttpGet("member")]
    public ActionResult<IEnumerable<Member>> Get([FromQuery] QueryParams queryParams)
    {
        if (queryParams.OrderBy != "" && queryParams.OrderBy != "firstname" && queryParams.OrderBy != "lastname")
        {
            ModelState.AddModelError("OrderBy", "Parameter not supported. Try firstname, lastname or do not specify it.");
        }

        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        // support for sorting
        var result = service.GetMembers();
        if (queryParams.OrderBy == "firstname")
            result = result.Where(obj => obj.MemberInfoV?.Firstname != null).OrderBy(obj => obj.MemberInfoV?.Firstname).ToList();
        else if (queryParams.OrderBy == "lastname")
            result = result.Where(obj => obj.MemberInfoV?.Lastname != null).OrderBy(obj => obj.MemberInfoV?.Lastname).ToList();

        if ((queryParams.PageNumber - 1) * queryParams.PageSize >= result.Count)
        {
            ModelState.AddModelError("PageNumber", "PageNumber is too big.");
            return BadRequest(ModelState);
        }

        bool hasnext = queryParams.PageNumber * queryParams.PageSize < result.Count;
        // support for paging
        result = result.Skip((queryParams.PageNumber - 1) * queryParams.PageSize).Take(queryParams.PageSize).ToList();

        var metadata = new
        {
            queryParams.PageNumber,
            queryParams.PageSize,
            hasnext,
        };
        Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(metadata));
        return result;
    }

    // Test member data output.  `curl http://localhost:5124/test/json` should
    // return the JSON data we're working with.
    [HttpGet("json")]
    public JsonDocument GetMemberJson()
    {
        return service.MemberJson;
    }
}
