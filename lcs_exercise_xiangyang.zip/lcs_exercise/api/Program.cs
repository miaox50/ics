using exercise.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Wire in the member data service to fetch XML into this process
builder.Services.AddSingleton<MemberDataService>();

builder.Services.AddCors( options => {
    options.AddPolicy(name: "MyPolicy",
    builder => {
        builder.AllowAnyOrigin().AllowAnyHeader().WithExposedHeaders("*");
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// app.UseHttpsRedirection();

// app.UseAuthorization();

app.UseCors("MyPolicy");

app.MapControllers();

app.Run();
